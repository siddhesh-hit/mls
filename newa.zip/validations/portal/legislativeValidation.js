const joi = require("joi");

// create legislative members validation
const createLegislativeValidation = (data) => {};

// update legislative members validation
const updateLegislativeValidation = (data) => {};

module.exports = {
  createLegislativeValidation,
  updateLegislativeValidation,
};
